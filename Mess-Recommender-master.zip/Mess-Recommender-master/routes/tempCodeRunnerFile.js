var arr=[{"c":13},{"a":11},{"b":12},{"d":14}];
arr.sort();
for(i in arr){
    console.log(arr[i]);
}
